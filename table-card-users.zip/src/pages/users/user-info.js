import React from 'react'

export const UserIndoIndex = () => {
  return (
    <div>UserIndoIndex</div>
  )
}
