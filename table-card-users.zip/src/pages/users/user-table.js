import React from "react";

export const UserTable = ({id, name, username, email, phone}) => {
  return (
    <tr>
      <th scope='row'>{id}</th>
      <td>{name}</td>
      <td>{username}</td>
      <td>{email}</td>
      <td>{phone}</td>
    </tr>
  );
};
