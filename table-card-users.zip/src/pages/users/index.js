import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { UserCard } from "./user-card";
import { UserTable } from "./user-table";
import "./users.css";
export const Users = () => {
  const [userInfo, setUserInfo] = useState([]);
  const [visibilityType, setVisibilityType] = useState("card");
  useEffect(() => {
    axios.get("http://jsonplaceholder.typicode.com/users").then((response) => {
      // console.log(response.data);
      setUserInfo(response.data);
    });
  }, []);
  const changeVisibility = (e) => {
    setVisibilityType(e.target.value);
  };
  return (
    <div>
      <h2>users</h2>

      <div className='container'>
        <select
          className='form-select mb-5 w-25'
          aria-label='Default select example'
          onChange={changeVisibility}
        >
          <option selected>انتخاب شیوه ی نمایش</option>
          <option value='card'>کارت</option>
          <option value='table'>جدول</option>
        </select>
        {visibilityType === "card" ? (
          <div className='row mx-0'>
            {userInfo.map((item) => (
              <UserCard
                id={item.id}
                name={item.name}
                username={item.username}
                email={item.email}
                phone={item.phone}
                key={item.id}
              />
            ))}
          </div>
        ) : (
          <div className='table-responsive'>
            <table className='table'>
              <thead>
                <tr>
                  <th scope='col'>#</th>
                  <th scope='col'>name</th>
                  <th scope='col'>username</th>
                  <th scope='col'>email</th>
                  <th scope='col'>phone</th>
                </tr>
              </thead>
              <tbody>
                {userInfo.map((item) => (
                  <UserTable
                    id={item.id}
                    name={item.name}
                    username={item.username}
                    email={item.email}
                    phone={item.phone}
                    key={item.id}
                  />
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
