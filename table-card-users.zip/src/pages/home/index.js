import React from 'react'

export const HomeIndex = () => {
  return (
    <>
        home
    </>
  )
}
